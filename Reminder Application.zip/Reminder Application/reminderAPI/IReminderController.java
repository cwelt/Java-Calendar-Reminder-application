package reminderAPI;

public interface IReminderController
{
	public void initializeApplication();
}
